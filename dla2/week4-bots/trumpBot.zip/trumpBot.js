var Twit = require('twit')

var T = new Twit({
  consumer_key:         'QcbqzseC6dqWqWXdb6kQej0vm',
  consumer_secret:      'DASh0doKLqPBu1iLlT5Azt4kAWEFbb3ImqeJuAONVYaZOqWa4Q',
  access_token:         '783360585383735296-lhC6xC051dn3803V3cIJplNSxyVr3qJ',
  access_token_secret:  '0gztuKhOAnNlTlLU0zWtBDF6nqudUxsUpw3VV5b3Haamw',
  timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
})
var fs = require('fs');
eval(fs.readFileSync("nodeMarkov.js","utf-8"));
var markov = new MarkovGeneratorWord(2,15)
var text = fs.readFileSync('../week3-markov/trump.txt', "utf-8")
markov.feed(text)
function generate(){
	var t = markov.generate()
	while(t.length > 140){
		t = markov.generate()
	}
	T.post('statuses/update', { status: t }, function(err, data, response) {
  		console.log(t)
	})
}
generate()
setInterval(generate,20 * 60 * 1000)