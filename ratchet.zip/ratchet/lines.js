let lines = `
life's a ratchet
his line not mine,
the poet and the novelist
wasting our best material on each other just to show that we could
showing off our abundance mindset
staying up late to prove our priorities
don't touch the night like that no more
could but don't
it is a ratchet tho
sometimes its better
not to test your coulds

lord save me from bad opinions and expensive habits
living in fear of waking up next to a pair of $3000 skis
and a preference for north colorado powder

that age old question
is it worth loving something [someone ] enough
to where you couldn't live without 

wouldn't be the same

not you anymore 
cept you, who's you?
that you back there ain't coming back
life's a ratchet
don't forget
the only you's the you that's left

seamless pays me back with time
to watch a video, to unwind
i've measured out my life in steam acheivements
spaced between a few bereavements
the ones i've had and the ones in store
podcast deckbox dark souls 4

used to think
life's elastic
retains its shape 
when you push past it
except you can't 
unstretch the sweater
just stretch your self til it fits better
and now your pants need stretching too
cept you cant stretch them same as you stretch you
you've got a belt but can't attach it
life's elastic, nah
life's a ratchet
`.split("\n");
